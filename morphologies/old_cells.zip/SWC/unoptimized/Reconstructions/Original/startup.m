set(0,'defaultfigurecolor',ones(1,3));
