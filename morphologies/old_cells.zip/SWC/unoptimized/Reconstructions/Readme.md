In almost all the swc files of the reconstructed neurons there were a lot of errors that caused the software to crash.

The crash was caused by the fact that in the .swc files there are multiple compartements that have a parent compartment of -1. This is normally only given to the first point in each file to specify the origination point.) 